import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import linregress


data = {}
plot = True


with open("Democracy index.txt", "r") as f:
    lines1 = f.readlines()
    for line in lines1:
        line = line.split()
        country = ""
        for word in line:
            try:
                float(word)
                break
            except:
                country += " "+word
        
        country = country.strip()
        data[country] = {}
        data[country]["demindex"] = float(line[-8])

with open("taxrates.txt", "r") as f:
    lines1 = f.readlines()
    for line in lines1:
        line = line.split()
        country = ""
        for word in line:
            try:
                float(word)
                break
            except:
                country += " "+word
        
        country = country.strip()
        try:
            data[country]["taxrate"] = float(line[-3])
        except:
            print(country+" not found")

tax = []
dem = []
for key in data:
    if len(data[key]) == 2:
        tax.append(data[key]["taxrate"])
        dem.append(data[key]["demindex"])

#print(data)


if plot:
    # Generate some example data
    np.random.seed(0)
    x = np.array(tax)
    y = np.array(dem)
    
    
    # Perform linear regression
    slope, intercept, rval, pval, stderr = linregress(x, y)
    print(f"Slope: {slope}\nIntercept: {intercept}\nrvalue: {rval}\npvalue: {pval}\nStandard error: {stderr}")
    
    # Compute y-values of the regression line
    reg_y = intercept + slope * x
    
    # Compute the 95% confidence interval for the regression line
    conf_int = 1.96 * stderr
    lower = reg_y - conf_int
    upper = reg_y + conf_int
    
    # Set axes
    fig,ax = plt.subplots()
    ax.set_xlabel("Personal tax rate, %")
    ax.set_ylabel("Democracy index")
    
    # Plot the scatterplot with the regression line and confidence intervals
    plt.scatter(x, y, label="Data")
    plt.plot(x, reg_y, color="red", label="Regression Line")
    plt.fill_between(x, lower, upper, color="red", alpha=0.2, label="95% Confidence Interval")
    plt.legend()
    plt.show()